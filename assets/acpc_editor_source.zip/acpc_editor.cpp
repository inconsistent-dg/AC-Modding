// ACPC Savegame editor by Thulinma
// License: Unlicense. Do with this code whatever you want!
// However, I would appreciate it if you credited the source if this code helped you in any way.
// Live long and prosper!
// - Thulinma

#include <iostream>
#include <sstream>
#include <fstream>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <iomanip>
#include <map>
#include <list>

const char * item_lookup(uint32_t ID){
#include "item_id_english.cpp"
  if (ID == 16){return "fertilizer";}
  if (ID == 19){return "honey";}
  if (ID == 22){return "river throw net";}
  if (ID == 26){return "sea throw net";}
  if (ID == 1301046){return "Bronze Treats";}
  if (ID == 1301047){return "Silver Treats";}
  if (ID == 1301048){return "Gold Treats";}
  if (ID == 1400049){return "Tommy's Fortune Cookie";}
  if (ID == 1400050){return "Timmy's Fortune Cookie";}
  if (ID == 1400051){return "Clothing Fortune Cookie";}
  if (ID == 1801040){return "Inkling's Splatted Cookie";}
  if (ID == 2001047){return "large tourney throw net";}
  if (ID == 2001083){return "tourney throw net";}
  if (ID == 2500046){return "Hello Kitty Cookie";}
  if (ID == 2500047){return "Cinnamoroll Cookie";}
  if (ID == 2500050){return "Pompompurin Cookie";}
  if (ID == 2500051){return "My Melody Cookie";}
  if (ID == 2501100){return "Kiki and Lala Cookie";}
  if (ID == 2501101){return "Kerokerokeroppi Cookie";}
  if (ID == 4200003){return "Sanrio Characters Cookie";}
  if (ID == 7000002){return "Complete Ticket";}
  return 0;
//2500049 adventuremap_npc_elp11 - Chai
//2502055 adventuremap_npc_rbt20 - Toby
//2501096 adventuremap_npc_cbr18 - Marty
//2501097 adventuremap_npc_der10 - Chelsea
//2502056 adventuremap_npc_shp14 - Étoile
//2500048 adventuremap_npc_gor11 - Rilla
}

const char * item_id_to_internal(uint32_t ID){
#include "item_id_convert.cpp"
  return 0;
}


std::string npc_lookup(std::string ID){
#include "villagers.cpp"
  return "";
}


/// Right rotate function. Shifts bytes off the least significant end, wrapping them to the most significant end.
static inline uint32_t rr(uint32_t x, uint32_t c){
  return ((x << (32 - c)) | ((x & 0xFFFFFFFF) >> c));
}

/// Adds 64 bytes of data to the current SHA256 hash.
/// hash is the current hash, represented by 8 unsigned longs.
/// data is the 64 bytes of data that need to be added.
static inline void sha256_add64(uint32_t *hash, const unsigned char *data){
  // Inspired by the pseudocode as available on Wikipedia on March 3rd, 2015.
  uint32_t w[64];
  for (unsigned int i = 0; i < 16; ++i){
    w[i] = (uint32_t)data[(i << 2) + 3] | ((uint32_t)data[(i << 2) + 2] << 8) |
           ((uint32_t)data[(i << 2) + 1] << 16) | ((uint32_t)data[(i << 2) + 0] << 24);
  }

  for (unsigned int i = 16; i < 64; ++i){
    uint32_t s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ ((w[i - 15] & 0xFFFFFFFF) >> 3);
    uint32_t s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ ((w[i - 2] & 0xFFFFFFFF) >> 10);
    w[i] = w[i - 16] + s0 + w[i - 7] + s1;
  }

  static uint32_t k[] ={0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
                         0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
                         0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
                         0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
                         0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                         0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
                         0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
                         0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
                         0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
                         0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                         0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};
  uint32_t a = hash[0];
  uint32_t b = hash[1];
  uint32_t c = hash[2];
  uint32_t d = hash[3];
  uint32_t e = hash[4];
  uint32_t f = hash[5];
  uint32_t g = hash[6];
  uint32_t h = hash[7];
  for (unsigned int i = 0; i < 64; ++i){
    uint32_t temp1 = h + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) + (g ^ (e & (f ^ g))) + k[i] + w[i];
    uint32_t temp2 = (rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)) + ((a & b) | (c & (a | b)));
    h = g;
    g = f;
    f = e;
    e = d + temp1;
    d = c;
    c = b;
    b = a;
    a = temp1 + temp2;
  }
  hash[0] += a;
  hash[1] += b;
  hash[2] += c;
  hash[3] += d;
  hash[4] += e;
  hash[5] += f;
  hash[6] += g;
  hash[7] += h;
}

/// Calculates a SHA256 digest as per NSAs SHA-2, returning it as binary.
/// Assumes output is big enough to contain 32 bytes of data.
void sha256bin(const unsigned char *input, const unsigned int in_len, unsigned char *output){
  // Initialize the hash
  uint32_t hash[] ={0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                     0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19};
  // Add as many whole blocks of 64 bytes as possible from the input, until < 64 are left.
  unsigned int offset = 0;
  while (offset + 64 <= in_len){
    sha256_add64(hash, input + offset);
    offset += 64;
  }
  // now, copy the remainder to a 64 byte buffer.
  unsigned char buffer[64];
  memcpy(buffer, input + offset, in_len - offset);
  // Calculate how much we've filled in that buffer
  offset = in_len - offset;
  // We know at least 1 byte must be empty, so we can safely do this
  buffer[offset] = 0x80; // append 0x80
  // fill to the end of the buffer with zeroes
  memset(buffer + offset + 1, 0, 64 - offset - 1);
  if (offset > 55){
    // There's no space for the length, add what we have and zero it
    sha256_add64(hash, buffer);
    memset(buffer, 0, 64);
  }
  unsigned long long bit_len = in_len << 3;
  // Write the length into the last 8 bytes
  buffer[56] = (bit_len >> 54) & 0xff;
  buffer[57] = (bit_len >> 48) & 0xff;
  buffer[58] = (bit_len >> 40) & 0xff;
  buffer[59] = (bit_len >> 32) & 0xff;
  buffer[60] = (bit_len >> 24) & 0xff;
  buffer[61] = (bit_len >> 16) & 0xff;
  buffer[62] = (bit_len >> 8) & 0xff;
  buffer[63] = (bit_len >> 0) & 0xff;
  // Add the last bit of buffer
  sha256_add64(hash, buffer);
  // Write result to output
  output[3] = hash[0] & 0xff;
  output[2] = (hash[0] >> 8) & 0xff;
  output[1] = (hash[0] >> 16) & 0xff;
  output[0] = (hash[0] >> 24) & 0xff;
  output[7] = hash[1] & 0xff;
  output[6] = (hash[1] >> 8) & 0xff;
  output[5] = (hash[1] >> 16) & 0xff;
  output[4] = (hash[1] >> 24) & 0xff;
  output[11] = hash[2] & 0xff;
  output[10] = (hash[2] >> 8) & 0xff;
  output[9] = (hash[2] >> 16) & 0xff;
  output[8] = (hash[2] >> 24) & 0xff;
  output[15] = hash[3] & 0xff;
  output[14] = (hash[3] >> 8) & 0xff;
  output[13] = (hash[3] >> 16) & 0xff;
  output[12] = (hash[3] >> 24) & 0xff;
  output[19] = hash[4] & 0xff;
  output[18] = (hash[4] >> 8) & 0xff;
  output[17] = (hash[4] >> 16) & 0xff;
  output[16] = (hash[4] >> 24) & 0xff;
  output[23] = hash[5] & 0xff;
  output[22] = (hash[5] >> 8) & 0xff;
  output[21] = (hash[5] >> 16) & 0xff;
  output[20] = (hash[5] >> 24) & 0xff;
  output[27] = hash[6] & 0xff;
  output[26] = (hash[6] >> 8) & 0xff;
  output[25] = (hash[6] >> 16) & 0xff;
  output[24] = (hash[6] >> 24) & 0xff;
  output[31] = hash[7] & 0xff;
  output[30] = (hash[7] >> 8) & 0xff;
  output[29] = (hash[7] >> 16) & 0xff;
  output[28] = (hash[7] >> 24) & 0xff;
}

/// Calculates a SHA256 digest as per NSAs SHA-2, returning it as a hexadecimal alphanumeric string.
std::string sha256(const unsigned char *input, const size_t in_len){
  unsigned char output[32];
  sha256bin(input, in_len, output);
  std::stringstream outStr;
  for (unsigned int i = 0; i < 32; ++i){
    outStr << std::hex << std::setw(2) << std::setfill('0') << (unsigned int)(output[i] & 0xff);
  }
  return outStr.str();
}

/// Calculates a SHA256 digest as per NSAs SHA-2, returning it as a hexadecimal alphanumeric string.
std::string sha256(const std::string & input){return sha256((unsigned char *)input.data(), input.size());}

uint32_t ntohl(uint32_t in){
  unsigned char * v = (unsigned char*)&in;
  return ((uint32_t)v[0] << 24) | ((uint32_t)v[1] << 16) | ((uint32_t)v[2] << 8) | (uint32_t)v[3];
}

uint64_t ntohll(uint64_t in){
  return ((uint64_t)ntohl(*(uint32_t*)&in) << 32) | (uint64_t)ntohl(*(uint32_t*)(((char*)&in)+4));
}

std::string getFBStr(char * ptr){
  uint32_t offset = *(uint32_t*)ptr;
  return std::string(ptr+offset+4, *(uint32_t*)(ptr+offset));
}

void setFBStr(char * ptr, const std::string & newVal){
  uint32_t offset = *(uint32_t*)ptr;
  if (newVal.size() == *(uint32_t*)(ptr+offset)){
    memcpy(ptr+offset+4, newVal.data(), *(uint32_t*)(ptr+offset));
  }else{
    std::cout << "Could not set string: not identical length!" << std::endl;
  }
}

std::string getStringArray(char * ptr){
  uint32_t offset = *(uint32_t*)ptr;
  uint32_t arrLen = *(uint32_t*)(ptr+offset);
  uint32_t * arrData = (uint32_t*)(ptr+offset+4);
  std::stringstream out;
  out << "[";
  for (size_t i = 0; i < arrLen; ++i){
    if (i > 0){out << ", ";}
    out << getFBStr((char*)&(arrData[i]));
  }
  out << "]";
  return out.str();
}

std::string getUintArray(char * ptr){
  uint32_t offset = *(uint32_t*)ptr;
  uint32_t arrLen = *(uint32_t*)(ptr+offset);
  uint32_t * arrData = (uint32_t*)(ptr+offset+4);
  std::stringstream out;
  out << "[";
  for (size_t i = 0; i < arrLen; ++i){
    if (i > 0){out << ", ";}
    out << arrData[i];
  }
  out << "]";
  return out.str();
}

std::string getItemArray(char * ptr){
  uint32_t offset = *(uint32_t*)ptr;
  uint32_t arrLen = *(uint32_t*)(ptr+offset);
  uint32_t * arrData = (uint32_t*)(ptr+offset+4);
  std::stringstream out;
  out << "[";
  for (size_t i = 0; i < arrLen; ++i){
    if (i > 0){out << ", ";}
    out << arrData[i];
    const char * item_name = item_lookup(arrData[i]);
    const char * item_internal = item_id_to_internal(arrData[i]);
    if (item_internal){out << " = " << item_internal;}
    if (item_name){out << " = " << item_name;}
  }
  out << "]";
  return out.str();
}

std::string getByteArray(char * ptr){
  uint32_t offset = *(uint32_t*)ptr;
  uint32_t arrLen = *(uint32_t*)(ptr+offset);
  uint8_t * arrData = (uint8_t*)(ptr+offset+4);
  std::stringstream out;
  out << "[";
  for (size_t i = 0; i < arrLen; ++i){
    if (i > 0){out << ", ";}
    out << (int)arrData[i];
  }
  out << "]";
  return out.str();
}

std::map<uint32_t, uint32_t> itemTarget;
std::map<uint32_t, uint8_t> itemAction;
bool addItemTarget(uint32_t item, const char * ident, const char * arg){
  size_t l = strlen(ident);
  if (!strncmp(arg, ident, l) && strlen(arg) > l){
    if (arg[l] == '-' || arg[l] == '+'){
      itemAction[item] = 2;
      itemTarget[item] = atol(arg + l + 1);
      if (arg[l] == '-'){itemTarget[item] *= -1;}
      std::cout << "Will add " << itemTarget[item] << " to " << item_lookup(item) << std::endl;
    }else{
      itemAction[item] = 1;
      itemTarget[item] = atol(arg + l);
      std::cout << "Will set " << item_lookup(item) << " to " << itemTarget[item] << std::endl;
    }
    return true;
  }
  return false;
}

void checkItemTarget(uint32_t & item_id, uint16_t & amount){
  if (itemAction.count(item_id)){
    uint8_t action = itemAction[item_id];
    if (action == 2){
      amount += itemTarget[item_id];
      std::cout << "Adding " << itemTarget[item_id] << " extra " << item_lookup(item_id) << "..." << std::endl;
    }else if (action == 1){
      amount = itemTarget[item_id];
      std::cout << "Setting " << item_lookup(item_id) << " count to " << itemTarget[item_id] << "..." << std::endl;
    }
  }
}

std::map<std::string, uint32_t> altTarget;
std::map<std::string, uint8_t> altAction;
std::map<std::string, std::string> altString;
bool addAltTarget(const std::string & alt, const char * ident, const char * arg){
  size_t l = strlen(ident);
  if (!strncmp(arg, ident, l) && strlen(arg) > l){
    if (arg[l] == '-' || arg[l] == '+'){
      altAction[alt] = 2;
      altTarget[alt] = atol(arg + l + 1);
      if (arg[l] == '-'){altTarget[alt] *= -1;}
      std::cout << "Will add " << altTarget[alt] << " to " << alt << std::endl;
    }else if (arg[l] >= '0' && arg[l] <= '9'){
      altAction[alt] = 1;
      altTarget[alt] = atol(arg + l);
      std::cout << "Will set " << alt << " to " << altTarget[alt] << std::endl;
    }else{
      altString[alt] = arg + l;
      std::cout << "Will set " << alt << " to " << altString[alt] << std::endl;
    }
    return true;
  }
  return false;
}

void checkAltTarget(const std::string & alt, uint32_t & amount){
  if (altAction.count(alt)){
    uint8_t action = altAction[alt];
    if (action == 2){
      amount += altTarget[alt];
      std::cout << "Adding " << altTarget[alt] << " extra " << alt << "..." << std::endl;
    }else if (action == 1){
      amount = altTarget[alt];
      std::cout << "Setting " << alt << " count to " << altTarget[alt] << "..." << std::endl;
    }
  }
}

uint16_t getUserStatic(uint32_t lowerPlayerID, int32_t v){
  // Thanks to marengg (Discord username) for the help in reverse engineering this function!
  uint32_t A = lowerPlayerID + 208387 * (v + 2835289) * (v + 2835289);
  int32_t B = (uint32_t)((float)(v + 2835289) * 1.5);
  return labs((int32_t)A * (int32_t)A * ((int32_t)A + B));
}

std::string getUserFruit1(const std::string & playerId, size_t fruitNo){
  // Thanks to marengg (Discord username) for the help in reverse engineering this function!
  std::list<std::string> fruitList = {"Apple", "Orange", "Peach", "Cherry", "Pear"};
  uint32_t lowerPlayerID = 0;
  for (size_t i = 8; i < 16; ++i){
    char c = playerId[i];
    lowerPlayerID <<= 4;
    lowerPlayerID |= ((c&15) + (((c&64)>>6) | ((c&64)>>3)));
  }
  size_t fruit;
  size_t A = getUserStatic(lowerPlayerID, 0);
  fruit = A % 5;
  std::list<std::string>::iterator it = fruitList.begin();
  for (size_t i = 0; i < fruit; ++i){++it;}
  if (!fruitNo){return *it;}
  fruitList.erase(it);

  A = getUserStatic(lowerPlayerID, 1) / 60.0;
  fruit = A % 4;
  it = fruitList.begin();
  for (size_t i = 0; i < fruit; ++i){++it;}
  return *it;
}

const char * getUserExoticFruit(const std::string & playerId){
  // Thanks to marengg (Discord username) for the help in reverse engineering this function!
  uint64_t pid64 = 0;
  for (size_t i = 0; i < 16; ++i){
    char c = playerId[i];
    pid64 <<= 4;
    pid64 |= ((c&15) + (((c&64)>>6) | ((c&64)>>3)));
  }
  uint64_t preSeed = 208387LL * (30 + 2835289) * (30 + 2835289);
  uint32_t seed = (pid64 ^ preSeed);
  uint64_t doubleSeed = ((uint64_t)seed << 32) | seed;
  uint32_t A = doubleSeed >> 24;
  uint32_t B = 305419896;
  uint32_t C = B ^ A;
  uint32_t v0 = 1812433253 * (C ^ (C >> 30)) + 1;
  uint32_t v1 = 1812433253 * (v0 ^ (v0 >> 30)) + 2;
  uint32_t v2 = 1812433253 * (v1 ^ (v1 >> 30)) + 3;
  uint32_t v3 = 1812433253 * (v2 ^ (v2 >> 30)) + 4;

  uint32_t result;
  for (size_t i = 0; i < 11; ++i){
    result = (v3 >> 19) ^ ((v0 ^ (unsigned int)(v0 << 11)) >> 8) ^ v3 ^ v0 ^ (v0 << 11);
    v0 = v1;
    v1 = v2;
    v2 = v3;
    v3 = result;
  }
  const char * fruits[] = {"Grape", "Lemon", "Lychee"};
  return fruits[result % 3];
}

std::string getFruits(const std::string & playerId){
  std::string F0 = getUserExoticFruit(playerId);
  std::string F1 = getUserFruit1(playerId, 0);
  std::string F2 = getUserFruit1(playerId, 1);
  return F0 +  ", " + F1 + ", " + F2;
}

void normalizeFruit(std::string & F, bool exotic){
  if (F.size() >= 1){
    if (F[0] >= 'A' && F[0] <= 'Z'){F[0] += 32;}
    if (F[0] == 'a' && !exotic){F = "Apple"; return;}
    if (F[0] == 'o' && !exotic){F = "Orange"; return;}
    if (F[0] == 'c' && !exotic){F = "Cherry"; return;}
    if (F[0] == 'g' && exotic){F = "Grape"; return;}
    if (F[0] == 'l'){
      if (F.size() >= 2){
        if (F[1] >= 'A' && F[1] <= 'Z'){F[1] += 32;}
        if (F[1] == 'e' && exotic){F = "Lemon"; return;}
        if (F[1] == 'y' && exotic){F = "Lychee"; return;}
      }
    }
    if (F[0] == 'p'){
      if (F.size() >= 4){
        if (F[3] >= 'A' && F[3] <= 'Z'){F[3] += 32;}
        if (F[3] == 'r' && !exotic){F = "Pear"; return;}
        if (F[3] == 'c' && !exotic){F = "Peach"; return;}
      }
    }
  }
  std::cout << "Could not recognize fruit: " << F << std::endl;
  F = "Unknown fruit";
  return;
}

std::string pid2hex(uint64_t pid){
  std::string hex = "0000000000000000";
  size_t offset = 15;
  while (pid){
    if ((pid & 0xf) < 10){
      hex[offset] = '0' + (pid & 0xf);
    }else{
      hex[offset] = 'a' - 10 + (pid & 0xf);
    }
    pid >>= 4;
    --offset;
  }
  return hex;
}

void checkFruitOverride(const std::string & playerId, std::map<std::string, std::string> & altString, std::string & setPlayerId){
  if (altString.count("Exotic Fruit") || altString.count("Basic Fruit 1") || altString.count("Basic Fruit 2")){
    if (!altString.count("Exotic Fruit")){altString["Exotic Fruit"] = getUserExoticFruit(playerId);}
    if (!altString.count("Basic Fruit 1")){altString["Basic Fruit 1"] = getUserFruit1(playerId, 0);}
    if (!altString.count("Basic Fruit 2")){altString["Basic Fruit 2"] = getUserFruit1(playerId, 1);}
    normalizeFruit(altString["Exotic Fruit"], true);
    normalizeFruit(altString["Basic Fruit 1"], false);
    normalizeFruit(altString["Basic Fruit 2"], false);
    if (altString["Exotic Fruit"] == "Unknown fruit"){
      std::cout << "Not sure what exotic fruit you wanted; not changing it." << std::endl;
      return;
    }
    if (altString["Basic Fruit 1"] == "Unknown fruit"){
      std::cout << "Not sure what basic fruit 1 you wanted; not changing it." << std::endl;
      return;
    }
    if (altString["Basic Fruit 2"] == "Unknown fruit"){
      std::cout << "Not sure what basic fruit 2 you wanted; not changing it." << std::endl;
      return;
    }
    if (altString["Basic Fruit 2"] == altString["Basic Fruit 1"]){
      std::cout << "Your two basic fruits may not be the same; not changing it." << std::endl;
      return;
    }
    // Convert player ID to number
    uint64_t pid64 = 0;
    for (size_t i = 0; i < 16; ++i){
      char c = playerId[i];
      pid64 <<= 4;
      pid64 |= ((c&15) + (((c&64)>>6) | ((c&64)>>3)));
    }
    // Try to find a fruit match nearby that ID...
    for (size_t i = 0; i < 1024; ++i){
      std::string down = pid2hex(pid64 - i);
      if (altString["Exotic Fruit"] == getUserExoticFruit(down)){
        if (altString["Basic Fruit 1"] == getUserFruit1(down, 0)){
          if (altString["Basic Fruit 2"] == getUserFruit1(down, 1)){
            setPlayerId = down;
            return;
          }
        }
      }
      std::string up = pid2hex(pid64 + i);
      if (altString["Exotic Fruit"] == getUserExoticFruit(up)){
        if (altString["Basic Fruit 1"] == getUserFruit1(up, 0)){
          if (altString["Basic Fruit 2"] == getUserFruit1(up, 1)){
            setPlayerId = up;
            return;
          }
        }
      }
    }
    std::cout << "Could not find a nearby ID to change to for the wanted fruit combination!" << std::endl;
  }
}

char xorkey[1000];
void generateXorKey(){
  // Thanks to marengg (Discord username) for the help in reverse engineering this function!
  uint32_t seed = (uint32_t)0x8A91F2BE48CCLL;
  uint64_t doubleSeed = ((uint64_t)seed << 32) | seed;
  uint32_t A = doubleSeed >> 24;
  uint32_t B = 305419896;
  uint32_t C = B ^ A;
  uint32_t v0 = 1812433253 * (C ^ (C >> 30)) + 1;
  uint32_t v1 = 1812433253 * (v0 ^ (v0 >> 30)) + 2;
  uint32_t v2 = 1812433253 * (v1 ^ (v1 >> 30)) + 3;
  uint32_t v3 = 1812433253 * (v2 ^ (v2 >> 30)) + 4;

  uint32_t result;
  for (size_t i = 0; i < 250; ++i){
    result = (v3 >> 19) ^ ((v0 ^ (unsigned int)(v0 << 11)) >> 8) ^ v3 ^ v0 ^ (v0 << 11);
    v0 = v1;
    v1 = v2;
    v2 = v3;
    v3 = result;
    xorkey[i*4 + 3] = (result & 0x000000FF);
    xorkey[i*4 + 2] = (result & 0x0000FF00) >> 8;
    xorkey[i*4 + 1] = (result & 0x00FF0000) >> 16;
    xorkey[i*4 + 0] = (result & 0xFF000000) >> 24;
  }
}


int main(int argc, char ** argv){
  if (argc < 2){
    std::cout << "Usage: " << argv[0] << " <input_file> [<output_file> [options]]" << std::endl;
    std::cout << "Options:" << std::endl;
    std::cout << "  --tokens=AMOUNT - Sets leaf tokens to given number (prefix number with - or + to remove/add)" << std::endl;
    std::cout << "  --bells=AMOUNT - Sets bells to given number (prefix number with - or + to remove/add)" << std::endl;
    std::cout << "  --okmedals=AMOUNT - Sets Ok Motors game medals to given number (prefix number with - or + to remove/add)" << std::endl;
    std::cout << "  --complete=AMOUNT - Sets Complete Tickets to given number (prefix number with - or + to remove/add)" << std::endl;
    std::cout << "  --goldtreats=AMOUNT - Sets Gold Treats to given number (prefix number with - or + to remove/add)" << std::endl;
    std::cout << "  --fruitexotic=lemon - Sets your exotic fruit to Lemon (or Grape/Lychee)" << std::endl;
    std::cout << "  --fruitbasic1=apple - Sets your basic fruit 1 to Apple (or Orange/Peach/Cherry/Pear)" << std::endl;
    std::cout << "  --fruitbasic2=apple - Sets your basic fruit 2 to Apple (or Orange/Peach/Cherry/Pear)" << std::endl;
    std::cout << "  --inventory=AMOUNT - Sets purchased inventory size (each purchase = 5 slots, prefix number with - or + to remove/add)" << std::endl;
    std::cout << "  --decrypted - Don't re-encrypt output file" << std::endl;
    return 1;
  }
  
  std::string infile, outfile;
  bool re_encrypt = true;
  std::string setPlayerId;
  std::string oldPlayerId;
  size_t nonopt_count = 0;
  for (size_t n = 1; n < argc; ++n){
    if (addAltTarget("Leaf Tokens", "--tokens=", argv[n])){continue;}
    if (addAltTarget("Bells", "--bells=", argv[n])){continue;}
    if (addAltTarget("Ok Motor Game Medals", "--okmedals=", argv[n])){continue;}
    if (addAltTarget("Exotic Fruit", "--fruitexotic=", argv[n])){continue;}
    if (addAltTarget("Basic Fruit 1", "--fruitbasic1=", argv[n])){continue;}
    if (addAltTarget("Basic Fruit 2", "--fruitbasic2=", argv[n])){continue;}
    if (addAltTarget("Purchased inventory size", "--inventory=", argv[n])){
      altAction["Purchased inventory slots"] = altAction["Purchased inventory size"];
      altTarget["Purchased inventory slots"] = altTarget["Purchased inventory size"] * 5;
      continue;
    }
    if (addItemTarget(7000002, "--complete=", argv[n])){continue;}
    if (addItemTarget(1301048, "--goldtreats=", argv[n])){continue;}
    if (argv[n] == std::string("--decrypted")){
      re_encrypt = false;
      continue;
    }
    if (argv[n] == std::string("--playerid")){
      setPlayerId = argv[n+1];
      n++;
      continue;
    }
    if (nonopt_count == 0){
      infile = argv[n];
      nonopt_count++;
      continue;
    }
    if (nonopt_count == 1){
      outfile = argv[n];
      nonopt_count++;
      continue;
    }
  }

  if (!infile.size()){
    std::cout << "No input file - aborting!" << std::endl;
    return 1;
  }


  generateXorKey();
  std::cout << "Reading save from " << infile << "..." << std::endl;
  std::ifstream iFile(infile.c_str(), std::ios::binary);
  std::string dec;
  size_t i = 0;
  while (iFile.good()){
    uint8_t iChar = iFile.get();
    if (iFile.eof()){break;}
    dec += (char)(iChar ^ xorkey[i++ % 999]);
  }

  if (memcmp(dec.data(), "C4FH", 4)){
    std::cout << "Not a ACPC save file or decryption failed. Aborting as a precaution!" << std::endl;
    return 2;
  }

  std::string calcedHash = sha256((unsigned char*)dec.data()+68, dec.size() - 68);
  if (dec.substr(4, 64) != calcedHash){
    std::cout << "Hash mismatch! Aborting as a precaution." << std::endl;
    std::cout << "Hash       = " << dec.substr(4, 64) << std::endl;
    std::cout << "Calculated = " << calcedHash << std::endl;
    return 2;
  }

  std::cout << "Version: " << ntohl(*(uint32_t*)(dec.data() + 72)) << std::endl;
  std::cout << "# of keys: " << ntohl(*(uint32_t*)(dec.data() + 76)) << std::endl;

  size_t offset = 80;
  i = 0;
  while (offset + 24 <= dec.size()){
    if (dec.substr(offset, 4) != "C4SI"){break;}
    size_t keyLen = ntohl(*(uint32_t*)(dec.data() + offset + 4));
    if (offset + 24 + keyLen > dec.size()){break;}
    std::string keyName = dec.substr(offset + 8, keyLen);
    uint64_t binSize = ntohll(*(uint64_t*)(dec.data() + offset + 8 + keyLen));
    uint64_t binOffset = ntohll(*(uint64_t*)(dec.data() + offset + 8 + keyLen + 8));
    std::cout << "Key #" << i << ": " << keyName << " is " << binSize << "b at offset " << binOffset << std::endl;
    if (false){
      std::cout << "Dumping: " << std::endl;
      for (size_t i = 0; i < binSize; ++i){
        std::cout << std::hex << std::setw(2) << std::setfill('0') << ((int)*(uint8_t*)(dec.data()+binOffset+i) & 0xff);
      }
      std::cout << std::dec << std::endl;
    }
    if (keyName == "UserProfile_1"){
      char * profilePtr = dec.data()+binOffset;
      char * rootTable = profilePtr + *(uint32_t*)profilePtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  Birthday = " << *(uint32_t*)(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){
        std::cout << "  Bells = " << *(uint32_t*)(rootTable + vTable[4]) << std::endl;
        checkAltTarget("Bells", *(uint32_t*)(rootTable + vTable[4]));
      }
      if (entryCount >= 4 && vTable[5]){std::cout << "  Exp = " << *(uint32_t*)(rootTable + vTable[5]) << std::endl;}
      if (entryCount >= 5 && vTable[6]){std::cout << "  RegisteredAt = " << *(uint32_t*)(rootTable + vTable[6]) << std::endl;}
      if (entryCount >= 6 && vTable[7]){std::cout << "  DealerCarLimit = " << *(uint32_t*)(rootTable + vTable[7]) << std::endl;}
      if (entryCount >= 7 && vTable[8]){std::cout << "  MagicNumber = " << *(uint32_t*)(rootTable + vTable[8]) << std::endl;}
      if (entryCount >= 8 && vTable[9]){
        std::cout << "  Leaf Tokens = " << *(uint32_t*)(rootTable + vTable[9]) << std::endl;
        checkAltTarget("Leaf Tokens", *(uint32_t*)(rootTable + vTable[9]));
      }
      goto nextone;
    }
    if (keyName.size() >= 23 && keyName.substr(0, 23) == "UserItemStockOneSlotSet"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){
        uint32_t* entryVector = (uint32_t*)(rootTable + vTable[3] + *(uint32_t*)(rootTable + vTable[3]));
        std::cout << "  " << entryVector[0] <<  " entries:" << std::endl;
        for (size_t e = 0; e < entryVector[0]; ++e){
          char * eTable = ((char*)&(entryVector[e+1])) + entryVector[e+1];
          uint16_t * eVTable = (uint16_t*)(eTable - *(int32_t*)eTable);
          size_t eeCount = (eVTable[0] / 2) - 2;
          std::cout << "   Entry " << (e+1) << ":";
          if (eeCount >= 5 && eVTable[6]){std::cout << " " << *(uint16_t*)(eTable + eVTable[6]) << "x ";}
          if (eeCount >= 1 && eVTable[2]){std::cout << " ID=" << *(uint32_t*)(eTable + eVTable[2]);}
          if (eeCount >= 2 && eVTable[3]){
            std::cout << "Item " << *(uint32_t*)(eTable + eVTable[3]);
            const char * item_name = item_lookup(*(uint32_t*)(eTable + eVTable[3]));
            const char * item_internal = item_id_to_internal(*(uint32_t*)(eTable + eVTable[3]));
            if (item_internal){std::cout << " = " << item_internal;}
            if (item_name){std::cout << " = " << item_name;}
          }
          if (eeCount >= 3 && eVTable[4]){std::cout << " date=" << *(uint32_t*)(eTable + eVTable[4]);}
          if (eeCount >= 4 && eVTable[5]){std::cout << " checked=" << (int)*(uint8_t*)(eTable + eVTable[5]);}
          if (eeCount >= 6 && eVTable[7]){std::cout << " GUID=" << getFBStr(eTable + eVTable[7]);}
          if (eeCount >= 7 && eVTable[8]){
            uint8_t put_place = *(uint8_t*)(eTable + eVTable[8]);
            if (put_place == 1){
              std::cout << " (in camper (1))";
            }else if (put_place == 2){
              std::cout << " (in campground (2))";
            }else if (put_place == 3){
              std::cout << " (worn on player (3))";
            }else if (put_place == 5){
              std::cout << " (in cabin (5))";
            }else{
              std::cout << " (in unknown (" << (int)put_place << ")";
            }
          }
          if (eeCount >= 8 && eVTable[9]){std::cout << " lock=" << (int)*(uint8_t*)(eTable + eVTable[9]);}
          std::cout << std::endl;
          if (eeCount >= 5 && eVTable[6] && eVTable[3]){
            checkItemTarget(*(uint32_t*)(eTable + eVTable[3]), *(uint16_t*)(eTable + eVTable[6]));
          }
        }
      }
      goto nextone;
    }
    if (keyName.size() >= 25 && keyName.substr(0, 25) == "UserPresentBalloonOneSlot"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  Enabled = " << (int)*(uint8_t*)(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){
        std::cout << "  NPC Label = " << getFBStr(rootTable + vTable[4]) << " (" << npc_lookup(getFBStr(rootTable + vTable[4])) << ")" << std::endl;
      }
      if (entryCount >= 4 && vTable[5]){std::cout << "  Rarity = " << *(uint32_t*)(rootTable + vTable[5]) << std::endl;}
      if (entryCount >= 5 && vTable[6]){std::cout << "  Position ID = " << (int)*(uint8_t*)(rootTable + vTable[6]) << std::endl;}
      if (entryCount >= 6 && vTable[7]){
        uint32_t* entryVector = (uint32_t*)(rootTable + vTable[7] + *(uint32_t*)(rootTable + vTable[7]));
        std::cout << "  " << entryVector[0] <<  " entries:" << std::endl;
        for (size_t e = 0; e < entryVector[0]; ++e){
          char * eTable = ((char*)&(entryVector[e+1])) + entryVector[e+1];
          uint16_t * eVTable = (uint16_t*)(eTable - *(int32_t*)eTable);
          size_t eeCount = (eVTable[0] / 2) - 2;
          std::cout << "   Entry " << (e+1) << ":" << std::endl;
          if (eeCount >= 1 && eVTable[2]){std::cout << "    Label = " << getFBStr(eTable + eVTable[2]) << std::endl;}
          if (eeCount >= 2 && eVTable[3]){std::cout << "    Num = " << *(uint16_t*)(eTable + eVTable[3]) << std::endl;}
          if (eeCount >= 3 && eVTable[4]){std::cout << "    Campaign ID = " << *(uint32_t*)(eTable + eVTable[4]) << std::endl;}
        }
      }
      goto nextone;
    }
    if (keyName.size() >= 18 && keyName.substr(0, 18) == "UserPresentBoxData"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  Expired at = " << *(uint32_t*)(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){std::cout << "  Inventory Data ID = " << getFBStr(rootTable + vTable[4]) << std::endl;}
      if (entryCount >= 4 && vTable[5]){std::cout << "  Opened at = " << *(uint32_t*)(rootTable + vTable[5]) << std::endl;}
      if (entryCount >= 5 && vTable[6]){std::cout << "  Route = " << *(uint32_t*)(rootTable + vTable[6]) << std::endl;}
      if (entryCount >= 6 && vTable[7]){std::cout << "  Route Option = " << getFBStr(rootTable + vTable[7]) << std::endl;}
      if (entryCount >= 7 && vTable[8]){std::cout << "  Item Label = " << getFBStr(rootTable + vTable[8]) << std::endl;}
      if (entryCount >= 8 && vTable[9]){std::cout << "  Item Amount = " << *(uint32_t*)(rootTable + vTable[9]) << std::endl;}
      if (entryCount >= 9 && vTable[10]){std::cout << "  Item Option = " << getFBStr(rootTable + vTable[10]) << std::endl;}
      goto nextone;
    }
    if (keyName.size() >= 39 && keyName.substr(0, 39) == "UserMaterialDropInfoItemDropInfoOneSlot"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  Item Pos ID = " << getFBStr(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){std::cout << "  Item Label = " << getFBStr(rootTable + vTable[4]) << std::endl;}
      if (entryCount >= 4 && vTable[5]){std::cout << "  Is active = " << (int)*(uint8_t*)(rootTable + vTable[5]) << std::endl;}
      if (entryCount >= 4 && vTable[6]){
        int32_t* entryVector = (int32_t*)(rootTable + vTable[6] + *(uint32_t*)(rootTable + vTable[6]));
        if (entryVector[0]){
          std::cout << "  Size list =";
          for (size_t n = 1; n <= entryVector[0]; ++n){
            std::cout << " " << entryVector[n];
          }
          std::cout << std::endl;
        }
      }
      goto nextone;
    }
    if (keyName.size() >= 39 && keyName.substr(0, 39) == "UserMaterialDropInfoItemDropTimeOneSlot"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  Label type = " << getFBStr(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){std::cout << "  Start timer time = " << *(uint32_t*)(rootTable + vTable[4]) << std::endl;}
      if (entryCount >= 4 && vTable[5]){std::cout << "  Refresh time = " << *(uint32_t*)(rootTable + vTable[5]) << std::endl;}
      goto nextone;
    }
    if (keyName.size() >= 26 && keyName.substr(0, 26) == "UserMyCampFurnitureOneSlot"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  Item label = " << getFBStr(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){std::cout << "  Position X = " << *(float*)(rootTable + vTable[4]) << std::endl;}
      if (entryCount >= 4 && vTable[5]){std::cout << "  Position Y = " << *(float*)(rootTable + vTable[5]) << std::endl;}
      if (entryCount >= 5 && vTable[6]){std::cout << "  Position Z = " << *(float*)(rootTable + vTable[6]) << std::endl;}
      if (entryCount >= 6 && vTable[7]){std::cout << "  Rotation Y = " << *(float*)(rootTable + vTable[7]) << std::endl;}
      if (entryCount >= 7 && vTable[8]){std::cout << "  Switch = " << (int)*(uint8_t*)(rootTable + vTable[8]) << std::endl;}
      if (entryCount >= 8 && vTable[9]){std::cout << "  GUID = " << getFBStr(rootTable + vTable[9]) << std::endl;}
      goto nextone;
    }
    if (keyName.size() >= 21 && keyName.substr(0, 21) == "UserStorehouseNameSet"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){
        uint32_t* entryVector = (uint32_t*)(rootTable + vTable[3] + *(uint32_t*)(rootTable + vTable[3]));
        std::cout << "  " << entryVector[0] <<  " entries:" << std::endl;
        for (size_t e = 0; e < entryVector[0]; ++e){
          char * eTable = ((char*)&(entryVector[e+1])) + entryVector[e+1];
          uint16_t * eVTable = (uint16_t*)(eTable - *(int32_t*)eTable);
          size_t eeCount = (eVTable[0] / 2) - 2;
          std::cout << "   Entry " << (e+1) << ":" << std::endl;
          if (eeCount >= 1 && eVTable[2]){std::cout << "    ID = " << *(uint32_t*)(eTable + eVTable[2]) << std::endl;}
          if (eeCount >= 2 && eVTable[3]){std::cout << "    Store ID = " << *(uint32_t*)(eTable + eVTable[3]) << std::endl;}
          std::cout << "    Name = " << std::string(eTable+eVTable[1]+4, *(uint32_t*)(eTable+eVTable[1])) << std::endl;
        }
      }
      goto nextone;
    }
    if (keyName.size() >= 30 && keyName.substr(0, 30) == "UserCraftPeddlerItemOneSlotSet"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){
        uint32_t* entryVector = (uint32_t*)(rootTable + vTable[3] + *(uint32_t*)(rootTable + vTable[3]));
        std::cout << "  " << entryVector[0] <<  " entries:" << std::endl;
        for (size_t e = 0; e < entryVector[0]; ++e){
          char * eTable = ((char*)&(entryVector[e+1])) + entryVector[e+1];
          uint16_t * eVTable = (uint16_t*)(eTable - *(int32_t*)eTable);
          size_t eeCount = (eVTable[0] / 2) - 2;
          std::cout << "   Entry " << (e+1) << ":" << std::endl;
          if (eeCount >= 1 && eVTable[2]){std::cout << "    Setting ID = " << *(uint32_t*)(eTable + eVTable[2]) << std::endl;}
          if (eeCount >= 2 && eVTable[3]){
            std::cout << "    Item " << *(uint32_t*)(eTable + eVTable[3]);
            const char * item_name = item_lookup(*(uint32_t*)(eTable + eVTable[3]));
            const char * item_internal = item_id_to_internal(*(uint32_t*)(eTable + eVTable[3]));
            if (item_internal){std::cout << " = " << item_internal;}
            if (item_name){std::cout << " = " << item_name;}
            std::cout << std::endl;
          }
          if (eeCount >= 3 && eVTable[5]){std::cout << "    Sale Status = " << (int)*(uint8_t*)(eTable + eVTable[4]) << std::endl;}
          if (eeCount >= 4 && eVTable[6]){std::cout << "    Seen = " << (int)*(uint8_t*)(eTable + eVTable[5]) << std::endl;}
        }
      }
      goto nextone;
    }
    if (keyName.size() >= 26 && keyName.substr(0, 26) == "UserCraftPeddlerOneSlotSet"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){
        uint32_t* entryVector = (uint32_t*)(rootTable + vTable[3] + *(uint32_t*)(rootTable + vTable[3]));
        std::cout << "  " << entryVector[0] <<  " entries:" << std::endl;
        for (size_t e = 0; e < entryVector[0]; ++e){
          char * eTable = ((char*)&(entryVector[e+1])) + entryVector[e+1];
          uint16_t * eVTable = (uint16_t*)(eTable - *(int32_t*)eTable);
          size_t eeCount = (eVTable[0] / 2) - 2;
          std::cout << "   Entry " << (e+1) << ":" << std::endl;
          if (eeCount >= 1 && eVTable[2]){std::cout << "    Setting ID = " << *(uint32_t*)(eTable + eVTable[2]) << std::endl;}
          if (eeCount >= 2 && eVTable[3]){std::cout << "    Disappear Time = " << *(uint32_t*)(eTable + eVTable[3]) << std::endl;}
          if (eeCount >= 3 && eVTable[4]){std::cout << "    End disappear interval time = " << *(uint32_t*)(eTable + eVTable[4]) << std::endl;}
        }
      }
      goto nextone;
    }
    if (keyName.size() >= 16 && keyName.substr(0, 16) == "UserCraftPeddler"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  End Lottery Time = " << *(uint32_t*)(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){std::cout << "  Seen Peddler Icon = " << (int)*(uint8_t*)(rootTable + vTable[4]) << std::endl;}
      if (entryCount >= 4 && vTable[5]){std::cout << "  Seen Painting Icon = " << (int)*(uint8_t*)(rootTable + vTable[5]) << std::endl;}
      goto nextone;
    }
    if (keyName.size() >= 18 && keyName.substr(0, 18) == "UserOkGamePlayData"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){
        std::cout << "  MedalNum = " << *(uint32_t*)(rootTable + vTable[3]) << std::endl;
        checkAltTarget("Ok Motor Game Medals", *(uint32_t*)(rootTable + vTable[3]));
      }
      if (entryCount >= 3 && vTable[4]){std::cout << "  DailyBigWinCount = " << *(uint32_t*)(rootTable + vTable[4]) << std::endl;}
      if (entryCount >= 4 && vTable[5]){std::cout << "  CeilPlayCount = " << *(uint32_t*)(rootTable + vTable[5]) << std::endl;}
      if (entryCount >= 5 && vTable[6]){std::cout << "  DailyTradeCount = " << *(uint32_t*)(rootTable + vTable[6]) << std::endl;}
      if (entryCount >= 6 && vTable[7]){std::cout << "  DailyMedalGetNum = " << *(uint32_t*)(rootTable + vTable[7]) << std::endl;}
      goto nextone;
    }
    if (keyName.size() >= 29 && keyName.substr(0, 29) == "UserFurniturePuzzlePlayerData"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  Stamina = " << *(uint32_t*)(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){std::cout << "  StaminaLastUpdate = " << *(uint32_t*)(rootTable + vTable[4]) << std::endl;}
      if (entryCount >= 4 && vTable[5]){std::cout << "  IsEndTutorial = " << (int)*(uint8_t*)(rootTable + vTable[5]) << std::endl;}
      if (entryCount >= 5 && vTable[6]){std::cout << "  EventFreePlay = " << *(uint32_t*)(rootTable + vTable[6]) << std::endl;}
      if (entryCount >= 6 && vTable[7]){std::cout << "  LastPlayLessonType = " << *(uint32_t*)(rootTable + vTable[7]) << std::endl;}
      goto nextone;
    }
    if (keyName.size() >= 30 && keyName.substr(0, 30) == "UserFurniturePuzzleProgressSet"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){
        uint32_t* entryVector = (uint32_t*)(rootTable + vTable[3] + *(uint32_t*)(rootTable + vTable[3]));
        std::cout << "  " << entryVector[0] <<  " entries:" << std::endl;
        for (size_t e = 0; e < entryVector[0]; ++e){
          char * eTable = ((char*)&(entryVector[e+1])) + entryVector[e+1];
          uint16_t * eVTable = (uint16_t*)(eTable - *(int32_t*)eTable);
          size_t eeCount = (eVTable[0] / 2) - 2;
          std::cout << "   Entry " << (e+1) << ":" << std::endl;
          if (eeCount >= 1 && eVTable[2]){std::cout << "    Lesson ID = " << *(uint32_t*)(eTable + eVTable[2]) << std::endl;}
          if (eeCount >= 2 && eVTable[3]){std::cout << "    Medal Num = " << *(uint32_t*)(eTable + eVTable[3]) << std::endl;}
          if (eeCount >= 3 && eVTable[4]){std::cout << "    New State = " << (int)*(uint8_t*)(eTable + eVTable[4]) << std::endl;}
          if (eeCount >= 4 && eVTable[5]){std::cout << "    Max Score = " << *(uint32_t*)(eTable + eVTable[5]) << std::endl;}
        }
      }
      goto nextone;
    }
    if (keyName.size() >= 24 && keyName.substr(0, 24) == "UserFriendCardOneSlotSet"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){
        uint32_t* entryVector = (uint32_t*)(rootTable + vTable[3] + *(uint32_t*)(rootTable + vTable[3]));
        std::cout << "  " << entryVector[0] <<  " entries:" << std::endl;
        for (size_t e = 0; e < entryVector[0]; ++e){
          char * eTable = ((char*)&(entryVector[e+1])) + entryVector[e+1];
          uint16_t * eVTable = (uint16_t*)(eTable - *(int32_t*)eTable);
          size_t eeCount = (eVTable[0] / 2) - 2;
          std::cout << "   Entry " << (e+1) << ":" << std::endl;
          if (eeCount >= 1 && eVTable[1]){std::cout << "    ID = " << *(uint32_t*)(eTable + eVTable[1]) << std::endl;}
          if (eeCount >= 1 && eVTable[2]){std::cout << "    Version = " << *(uint32_t*)(eTable + eVTable[2]) << std::endl;}
          if (eeCount >= 2 && eVTable[3]){
            std::cout << "    Player ID = " << getFBStr(eTable + eVTable[3]) << std::endl;
            if (setPlayerId.size() && oldPlayerId == getFBStr(eTable + eVTable[3]) && oldPlayerId != setPlayerId){
              std::cout << "Updating to " << setPlayerId << "..." << std::endl;
              setFBStr(eTable + eVTable[3], setPlayerId);
            }
            std::cout << "      Fruits: " << getFruits(getFBStr(eTable + eVTable[3])) << std::endl;
          }
          if (eeCount >= 3 && eVTable[4]){std::cout << "    Player Name = " << getFBStr(eTable + eVTable[4]) << std::endl;}
          if (eeCount >= 4 && eVTable[5]){std::cout << "    Partner ID = " << *(uint32_t*)(eTable + eVTable[5]) << std::endl;}
          if (eeCount >= 5 && eVTable[6]){std::cout << "    Sex = " << *(uint32_t*)(eTable + eVTable[6]) << std::endl;}
          if (eeCount >= 6 && eVTable[7]){std::cout << "    Eye Parts = " << *(uint32_t*)(eTable + eVTable[7]) << std::endl;}
          if (eeCount >= 7 && eVTable[8]){std::cout << "    Hair Style = " << *(uint32_t*)(eTable + eVTable[8]) << std::endl;}
          if (eeCount >= 8 && eVTable[9]){std::cout << "    Eye Color = " << *(uint32_t*)(eTable + eVTable[9]) << std::endl;}
          if (eeCount >= 9 && eVTable[10]){std::cout << "    Hair Color = " << *(uint32_t*)(eTable + eVTable[10]) << std::endl;}
          if (eeCount >= 10 && eVTable[11]){std::cout << "    Skin Color = " << *(uint32_t*)(eTable + eVTable[11]) << std::endl;}
          if (eeCount >= 11 && eVTable[12]){std::cout << "    Player Clothes = " << getItemArray(eTable + eVTable[12]) << std::endl;}
          if (eeCount >= 12 && eVTable[13]){std::cout << "    Partner Clothes = " << getItemArray(eTable + eVTable[13]) << std::endl;}
          if (eeCount >= 13 && eVTable[14]){std::cout << "    BG Color = " << *(uint32_t*)(eTable + eVTable[14]) << std::endl;}
          if (eeCount >= 14 && eVTable[15]){std::cout << "    Posing = " << *(uint32_t*)(eTable + eVTable[15]) << std::endl;}
          if (eeCount >= 15 && eVTable[16]){std::cout << "    Last Login = " << *(uint32_t*)(eTable + eVTable[16]) << std::endl;}
          if (eeCount >= 16 && eVTable[17]){std::cout << "    Level = " << *(uint32_t*)(eTable + eVTable[17]) << std::endl;}
          if (eeCount >= 17 && eVTable[18]){std::cout << "    Player Design ID = " << getStringArray(eTable + eVTable[18]) << std::endl;}
          if (eeCount >= 18 && eVTable[19]){std::cout << "    Partner Design ID = " << getStringArray(eTable + eVTable[19]) << std::endl;}
        }
      }
      goto nextone;
    }
    if (keyName.size() >= 24 && keyName.substr(0, 24) == "UserItemFortuneCookieSet"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){
        uint32_t* entryVector = (uint32_t*)(rootTable + vTable[3] + *(uint32_t*)(rootTable + vTable[3]));
        std::cout << "  " << entryVector[0] <<  " entries:" << std::endl;
        for (size_t e = 0; e < entryVector[0]; ++e){
          char * eTable = ((char*)&(entryVector[e+1])) + entryVector[e+1];
          uint16_t * eVTable = (uint16_t*)(eTable - *(int32_t*)eTable);
          size_t eeCount = (eVTable[0] / 2) - 2;
          std::cout << "   Entry " << (e+1) << ":" << std::endl;
          if (eeCount >= 1 && eVTable[2]){std::cout << "    ID = " << *(uint32_t*)(eTable + eVTable[2]) << std::endl;}
          if (eeCount >= 2 && eVTable[3]){std::cout << "    GUID = " << getFBStr(eTable + eVTable[3]) << std::endl;}
          if (eeCount >= 3 && eVTable[4]){std::cout << "    Route = " << *(uint32_t*)(eTable + eVTable[4]) << std::endl;}
          if (eeCount >= 4 && eVTable[5]){std::cout << "    Lotted Item IDs = " << getItemArray(eTable + eVTable[5]) << std::endl;}
          if (eeCount >= 5 && eVTable[6]){std::cout << "    Lotted Item Quants = " << getByteArray(eTable + eVTable[6]) << std::endl;}
          if (eeCount >= 6 && eVTable[7]){std::cout << "    Bomus Item ID = " << *(uint32_t*)(eTable + eVTable[7]) << std::endl;}
          if (eeCount >= 7 && eVTable[8]){std::cout << "    Bomus Item Quant = " << *(uint8_t*)(eTable + eVTable[8]) << std::endl;}
          if (eeCount >= 8 && eVTable[9]){std::cout << "    Omen ID = " << *(uint32_t*)(eTable + eVTable[9]) << std::endl;}
          if (eeCount >= 9 && eVTable[10]){std::cout << "    Eating ID = " << *(uint32_t*)(eTable + eVTable[10]) << std::endl;}
        }
      }
      goto nextone;
    }
    if (keyName.size() >= 30 && keyName.substr(0, 30) == "UserProfilePublicContainorSize"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  Purchase Count = " << *(uint32_t*)(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){std::cout << "  Current Size = " << *(uint32_t*)(rootTable + vTable[4]) << std::endl;}
      if (keyName == "UserProfilePublicContainorSize_2" && entryCount >= 3 && vTable[3] && vTable[4]){
        checkAltTarget("Purchased inventory size", *(uint32_t*)(rootTable + vTable[3]));
        checkAltTarget("Purchased inventory slots", *(uint32_t*)(rootTable + vTable[4]));
      }
      goto nextone;
    }
    if (keyName.size() >= 22 && keyName.substr(0, 22) == "UserCraftObjectOneSlot"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  Item Label = " << getFBStr(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){std::cout << "  Is Unlocked = " << (int)*(uint8_t*)(rootTable + vTable[4]) << std::endl;}
      if (entryCount >= 4 && vTable[5]){std::cout << "  Is New = " << (int)*(uint8_t*)(rootTable + vTable[5]) << std::endl;}
      if (entryCount >= 5 && vTable[6]){std::cout << "  Level = " << *(uint32_t*)(rootTable + vTable[6]) << std::endl;}
      goto nextone;
    }
    if (keyName.size() >= 10 && keyName.substr(0, 10) == "__playerid"){
      char * binPtr = dec.data()+binOffset;
      std::cout << "  Player ID = " << std::string(binPtr, binSize) << std::endl;
      oldPlayerId = std::string(binPtr, binSize);
      checkFruitOverride(oldPlayerId, altString, setPlayerId);
      if (setPlayerId.size() == binSize){
        std::cout << "Setting Player ID to " << setPlayerId << std::endl;
        memcpy(binPtr, setPlayerId.data(), binSize);
      }
      std::cout << "    Fruits: " << getFruits(std::string(binPtr, binSize)) << std::endl;
    }
    if (keyName.size() >= 21 && keyName.substr(0, 21) == "UserFortuneCookieShop"){
      char * binPtr = dec.data()+binOffset;
      char * rootTable = binPtr + *(uint32_t*)binPtr;
      uint16_t * vTable = (uint16_t*)(rootTable - *(int32_t*)rootTable);
      size_t entryCount = (vTable[0] / 2) - 2;
      if (entryCount >= 1 && vTable[2]){std::cout << "  ID = " << *(uint32_t*)(rootTable + vTable[2]) << std::endl;}
      if (entryCount >= 2 && vTable[3]){std::cout << "  Stocked At = " << *(uint32_t*)(rootTable + vTable[3]) << std::endl;}
      if (entryCount >= 3 && vTable[4]){
        std::cout << "  Display Labels = " << getStringArray(rootTable + vTable[4]) << std::endl;
      }
      if (entryCount >= 4 && vTable[5]){
        std::cout << "  Display States = " << getByteArray(rootTable + vTable[5]) << " (1 = available, 2 = sold out)" << std::endl;
      }
      if (entryCount >= 5 && vTable[6]){std::cout << "  Now Point = " << *(uint32_t*)(rootTable + vTable[6]) << std::endl;}
      if (entryCount >= 6 && vTable[7]){std::cout << "  Filled Point Card Number = " << *(uint32_t*)(rootTable + vTable[7]) << std::endl;}
      if (entryCount >= 7 && vTable[8]){std::cout << "  Eat Cookie Label = " << getFBStr(rootTable + vTable[8]) << std::endl;}
      if (entryCount >= 8 && vTable[9]){std::cout << "  Eat Purchase Type = " << (int)*(uint8_t*)(rootTable + vTable[9]) << std::endl;}
      if (entryCount >= 9 && vTable[10]){std::cout << "  Lotted Item Counts Per = " << getByteArray(rootTable + vTable[10]) << std::endl;}
      if (entryCount >= 10 && vTable[11]){std::cout << "  Lotted Item IDs = " << getItemArray(rootTable + vTable[11]) << std::endl;}
      if (entryCount >= 11 && vTable[12]){std::cout << "  Lotted Item Quants = " << getUintArray(rootTable + vTable[12]) << std::endl;}
      if (entryCount >= 12 && vTable[13]){std::cout << "  Bonus Item IDs = " << getItemArray(rootTable + vTable[13]) << std::endl;}
      if (entryCount >= 13 && vTable[14]){std::cout << "  Bonus Item Quants = " << getByteArray(rootTable + vTable[14]) << std::endl;}
      if (entryCount >= 14 && vTable[15]){std::cout << "  Eat Omen IDs = " << getUintArray(rootTable + vTable[15]) << std::endl;}
      if (entryCount >= 15 && vTable[16]){std::cout << "  Eat Eating ID = " << *(uint32_t*)(rootTable + vTable[16]) << std::endl;}
      if (entryCount >= 16 && vTable[17]){std::cout << "  Presented Group Nums = " << getUintArray(rootTable + vTable[17]) << std::endl;}
      if (entryCount >= 17 && vTable[18]){std::cout << "  Eat Item New Flags = " << getByteArray(rootTable + vTable[18]) << std::endl;}
      if (entryCount >= 18 && vTable[19]){std::cout << "  Eat Bonus New Flags = " << getByteArray(rootTable + vTable[19]) << std::endl;}
      if (entryCount >= 19 && vTable[20]){std::cout << "  Eat Route Type = " << *(uint32_t*)(rootTable + vTable[20]) << std::endl;}
      if (entryCount >= 20 && vTable[21]){std::cout << "  Eat Expired At = " << *(uint32_t*)(rootTable + vTable[21]) << std::endl;}
      if (entryCount >= 21 && vTable[22]){std::cout << "  Total Points During Eat = " << *(uint32_t*)(rootTable + vTable[22]) << std::endl;}
      if (entryCount >= 22 && vTable[23]){std::cout << "  Send Post Items Count By Eat = " << (int)*(uint8_t*)(rootTable + vTable[23]) << std::endl;}
      if (entryCount >= 23 && vTable[24]){std::cout << "  Is Eat Multi = " << (int)*(uint8_t*)(rootTable + vTable[24]) << std::endl;}
      goto nextone;
    }




nextone:
    offset += 24 + keyLen;
    ++i;
  }

  if (!outfile.size()){
    std::cout << "No output file. Exiting because we're done." << std::endl;
    return 0;
  }
  std::cout << "Patching hash..." << std::endl;
  std::string newHash = sha256((unsigned char*)dec.data()+68, dec.size() - 68);
  memcpy(dec.data()+4, newHash.data(), 64);

  if (re_encrypt){
    std::cout << "Re-encrypting..." << std::endl;
    for (i = 0; i < dec.size(); ++i){dec[i] ^= xorkey[i % 999];}
  }

  std::ofstream oFile(outfile.c_str(), std::ios::binary);
  oFile.write(dec.data(), dec.size());
  std::cout << "Written new (" << (re_encrypt?"encrypted":"decrypted") << ") save to " << outfile << "!" << std::endl;
  return 0;
}
