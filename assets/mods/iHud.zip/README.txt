===========================================================================================
MODDED SWITCH IS NEEDED TO USE. NOT MODDED ALREADY? https://ac-modding.com/switch-guide
===========================================================================================
iHud
===========

This mod completely hides the hud (map, phone, time and date). 
Great for screenshots and cinematic videos.
It's a small and simple BCSV edit.

# How does it work?

In PlayerStateParam.bcsv, the HideHud's (hash 5681a1c3) functionality is to hide the hud 
when entering a certain state. Things like using a tool, moving furniture, and sitting down
on stumps hide the hud by default.

This mod hides the hud in every state, so even when idling you don't see anything.

# How to install?

Extract the zip file, and merge the atmosphere folder in here with the one on your Switch.
To ensure it's installed correctly, make sure your directory looks like this:

atmosphere
 └─contents
     └─01006F8002326000
         └─romFs
           ├───Bcsv
           │       PlayerStateParam.bcsv
           └───System
                 └─Resource
                       ResourceSizeTable.srsizetable

=======
CREDITS
=======
created by @inconsistent_dg   (twitter, twitch youtube)
           @inconsistent      (speedrun.com)
           @inconsistent#2152 (discord)
https://ac-modding.com