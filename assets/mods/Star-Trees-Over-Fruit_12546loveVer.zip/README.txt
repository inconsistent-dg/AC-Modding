===========================================================================================
MODDED SWITCH IS NEEDED TO USE. NOT MODDED ALREADY? https://ac-modding.com/switch-guide
===========================================================================================
Star Trees Over Fruit - Heart Crystal Ver.
========================

This mod changes the growth of all fruit trees into star fragments. 
(or for this version of the mod, the apple is a heart crystal)
You can request for a custom version of the mod if you want another type of fragment.
Read below to see what each fruit tree turns into:

Apple  : Heart Crystal
Cherry : Cancer
Coconut: Taurus
Orange : Scorpius
Peach  : Normal Star Fragment
Pear   : Large Star Fragment

# How does it work?

In FgMainParam.bcsv, the NutItem's (hash be17c845) functionality is to state the item ID
that something else grows up into. 
E.g. sapling -> tree stage 1, red cosmos stems -> red cosmos buds, etc.

This mod changes the item ID that each fruit tree has when fully grown, so instead of
the apple ID (2213) I change it to the heart crystal ID (12546)

# How to install?

Extract the zip file, and merge the atmosphere folder in here with the one on your Switch.
To ensure it's installed correctly, make sure your directory looks like this:

atmosphere
 └─contents
     └─01006F8002326000
         └─romFs
           ├───Bcsv
           │       FgMainParam.bcsv
           └───System
                 └─Resource
                       ResourceSizeTable.srsizetable

=======
CREDITS
=======
created by @inconsistent_dg   (twitter, twitch youtube)
           @inconsistent      (speedrun.com)
           @inconsistent#2152 (discord)
https://ac-modding.com